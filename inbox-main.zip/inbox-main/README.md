# German Email Inbox App

Password-protected inbox-style React app to display mission emails.

- Each email is a component
- Editable in `/src/emails/`
- Routing via `/email/:id`
- Password is hardcoded as `lucas`
